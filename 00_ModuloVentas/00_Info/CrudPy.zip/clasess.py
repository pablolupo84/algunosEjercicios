from conexion import *

class Articulos(Conexion):
    
    def insertar(self,d,c,s,pv):
        cnx=self.conectar()
        cursor = cnx.cursor()
        cursor.execute("INSERT INTO articulos VALUES(null,'"+d+"','"+c+"','"+s+"','"+pv+"',null)")
        cnx.commit()
        self.CerrarConexion(cnx)

    def cargar(self,id_articulo):
        cnx=self.conectar()
        cursor = cnx.cursor()
        cursor.execute("SELECT * FROM articulos WHERE id_articulo="+str(id_articulo))
        arreglo = []
        for articulo in cursor:
            arreglo.append(articulo)
        self.CerrarConexion(cnx)
        return arreglo

    def modificar(self,d,c,s,pv,id_articulo):
        cnx = self.conectar()
        cursor = cnx.cursor()
        cursor.execute("UPDATE articulos SET descripcion='"+d+"',codigo='"+c+"',stock='"+s+"',precio_vta='"+pv+"' WHERE id_articulo='"+str(id_articulo)+"'")
        cnx.commit()
        self.CerrarConexion(cnx)

    def buscar(self,cadena):
        cnx = self.conectar()
        cursor = cnx.cursor()
        cursor.execute("SELECT * FROM articulos WHERE descripcion LIKE '%"+str(cadena)+"%'")
        arreglo = []
        for articulo in cursor:
            arreglo.append(articulo)
        self.CerrarConexion(cnx)
        return arreglo

    def consultar(self):
        cnx = self.conectar()
        cursor = cnx.cursor()
        cursor.execute("SELECT * FROM articulos")
        arreglo = []
        for articulos in cursor:
            arreglo.append(articulos)
        self.CerrarConexion(cnx)
        return arreglo

    def eliminar(self,id_articulo):
        cnx = self.conectar()
        cursor = cnx.cursor()
        cursor.execute("DELETE FROM articulos WHERE id_articulo="+str(id_articulo))
        cnx.commit()
        self.CerrarConexion(cnx)

class Clientes (Conexion):
    
    def insertar(self,di,rs,d,tel,ce,):
        cnx=self.conectar()
        cursor = cnx.cursor()
        cursor.execute("INSERT INTO clientes VALUES(null,'"+di+"','"+rs+"','"+d+"','"+tel+"','"+ce+"')")
        cnx.commit()
        self.CerrarConexion(cnx)

    def cargar(self,id_cliente):
        cnx=self.conectar()
        cursor = cnx.cursor()
        cursor.execute("SELECT * FROM cliente WHERE idp_cliente="+str(id_cliente))
        arreglo = []
        for cliente in cursor:
            arreglo.append(cliente)
        self.CerrarConexion(cnx)
        return arreglo

    def modificar(self,di,rs,d,tel,ce,id_cliente):
        cnx = self.conectar()
        cursor = cnx.cursor()
        cursor.execute("UPDATE profesor SET dni_cuit='"+di+"',razon_social='"+rs+"',domicilio='"+d+"',telefono='"+tel+"',celular='"+ce+"' WHERE id_cliente='"+str(id_cliente)+"'")
        cnx.commit()
        self.CerrarConexion(cnx)

    def buscar(self,cadena):
        cnx = self.conectar()
        cursor = cnx.cursor()
        cursor.execute("SELECT * FROM clientes WHERE razon_social LIKE '%"+str(cadena)+"%'")
        arreglo = []
        for cliente in cursor:
            arreglo.append(cliente)
        self.CerrarConexion(cnx)
        return arreglo

    def consultar(self):
        cnx = self.conectar()
        cursor = cnx.cursor()
        cursor.execute("SELECT * FROM clientes")
        arreglo = []
        for cliente in cursor:
            arreglo.append(cliente)
        self.CerrarConexion(cnx)
        return arreglo

    def eliminar(self,id_cliente):
        cnx = self.conectar()
        cursor = cnx.cursor()
        cursor.execute("DELETE FROM clientes WHERE id_cliente="+str(id_cliente))
        cnx.commit()
        self.CerrarConexion(cnx)
        
        
#Ventas
class Ventas(Conexion):

    def venta(self,id_articulo,id_cliente):
        cnx = self.conectar()
        cursor = cnx.cursor()
        cursor.execute("SELECT FROM articulos WHERE id_articulo="+str(id_articulo))
        cnx.commit()
        cursor.execute("INSERT INTO ventas")
        self.CerrarConexion(cnx)
        
#Metodo para vender

    def vender(self,id_articulo,id_cliente):
        cnx = self.conectar()
        cursor = cnx.cursor()
        cursor.execute("Select")
        
